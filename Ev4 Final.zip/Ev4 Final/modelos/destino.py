class Destino:
    def __init__(self, id, nombre, descripcion, actividades, costo):
        self.id = id
        self.nombre = nombre
        self.descripcion = descripcion
        self.actividades = actividades
        self.costo = costo
